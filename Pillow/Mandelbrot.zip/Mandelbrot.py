from PIL import Image
import math

c = (-1.5, 1.5)
z = (0, 0)

xSize = 1
ySize = 1

image = Image.new("RGB", (xSize, ySize))

def mandelbrot():
    global z
    zSquared = (z[0]**2 - z[1]**2, 2 * z[0] * z[1])
    zNew = (zSquared[0] + c[0], zSquared[1] + c[1])
    if (zNew[0]**2 + zNew[1]**2) >= 4:
        return False
    else:
        z = zNew
        return True 

if not mandelbrot():
    # Red
    image.putpixel((0, 0), (255, 0, 0))
else:
    if not mandelbrot():
        # Green
        image.putpixel((0, 0), (0, 255, 0))
    else:
        # Blue
        image.putpixel((0, 0), (0, 0, 255))

image.save("Mandelbrot.png")

